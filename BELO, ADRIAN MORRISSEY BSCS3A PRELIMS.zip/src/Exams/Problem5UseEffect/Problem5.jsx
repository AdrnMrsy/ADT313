import { useEffect, useState } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [isTyping, setIsTyping] = useState(false); 
  const [input, setInput] = useState("");

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false); 
    }, 3000); 

    return () => clearTimeout(timer);
  }, []);

  let typingTimer;

  const handleInputChange = (event) => {
    setInput(event.target.value);
    setIsTyping(true); 

    clearTimeout(typingTimer); 
    typingTimer = setTimeout(() => {
      setIsTyping(false); 
    },3000);
  };

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <div style={{ display: 'block' }}>
          Input: <input type="text" onChange={handleInputChange} />
          <p>{isTyping ? "User is typing..." : "User is idle..."}</p>
        </div>
      )}
    </>
  );
}
