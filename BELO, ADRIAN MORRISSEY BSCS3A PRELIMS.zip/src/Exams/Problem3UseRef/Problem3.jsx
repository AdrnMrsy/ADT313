import { useRef } from "react";
function Problem3() {
  const inputRefs = useRef([]);

  const handleButtonClick = () => {
    for (let ref of inputRefs.current) {
      if (ref && ref.value === '') {
        ref.focus();
        break;
      }
    }
  };

  return (
    <>
      <div style={{ display: 'block' }}>
        Input 1: <input type='text' ref={inputRefs}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 2: <input type='text'ref={inputRefs}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 3: <input type='text' ref={inputRefs}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 4: <input type='text' ref={inputRefs}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 5: <input type='text' ref={inputRefs}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 6: <input type='text' ref={inputRefs}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 7: <input type='text'ref={inputRefs}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 8: <input type='text' ref={inputRefs}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 9: <input type='text' ref={inputRefs}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 10: <input type='text' ref={inputRefs}/>
      </div>
      <button type='button' onClick={handleButtonClick}>I'm a button</button>
    </>
  );
}

export default Problem3;
//Students must programatically focus/select on the empty textbox when
//the users click the button.
